# ReverseShield 🔍

A lightweight **C++20** binary reverse-engineering toolkit with a **Dear ImGui** dark UI.

## Features

| Panel | Description |
|-------|-------------|
| **Hex View** | Hex + ASCII dump, search (text/hex), byte inspector |
| **Entropy** | Shannon entropy chart via ImPlot, per-section table |
| **Strings** | Scored string extraction — URLs, tokens, paths ranked first |
| **File Info** | Format metadata, architecture, sections, import table |

### Supported formats
`PE` · `ELF 32/64` · `Android DEX` · `APK/ZIP` · `Mach-O` · Raw binary

---

## Build (Desktop)

```bash
# Prerequisites: CMake ≥ 3.20, GCC/Clang with C++20, OpenGL dev libs
# Ubuntu: sudo apt install cmake build-essential libgl-dev libglu1-mesa-dev

git clone https://github.com/yourname/ReverseShield
cd ReverseShield

cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j$(nproc)

./build/ReverseShield
```

CMake auto-downloads SDL2, Dear ImGui, ImPlot via FetchContent.

---

## GitHub Actions — APK

See `.github/workflows/build-apk.yml`.

### Setup secrets

| Secret | Value |
|--------|-------|
| `KEYSTORE_BASE64` | `base64 your-keystore.jks` |
| `KEY_ALIAS` | Key alias inside keystore |
| `KEY_PASSWORD` | Key password |
| `STORE_PASSWORD` | Keystore password |

### Trigger

```bash
# Push a version tag to trigger full release
git tag v1.0.0
git push origin v1.0.0
```

Artifacts (split APKs + AAB) are attached to the GitHub Release automatically.

---

## Controls

- **File → Open** or **drag & drop** a binary onto the window
- Click any hex byte to inspect it in the status bar
- Strings panel: adjust **Min Score** slider to filter by interestingness
- Entropy: red blocks → high entropy → possible encryption/packing

---

## License

MIT
