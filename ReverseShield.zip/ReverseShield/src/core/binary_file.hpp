#pragma once
// ╔══════════════════════════════════════════════════════════════╗
// ║          ReverseShield — Binary Analysis Core               ║
// ║  Supports: PE, ELF, DEX, APK/ZIP, Mach-O detection         ║
// ╚══════════════════════════════════════════════════════════════╝

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

namespace RS {

// ─────────────────────────────────────────────────────────────────────────────
//  Enums & POD structs
// ─────────────────────────────────────────────────────────────────────────────

enum class FileType { Unknown, PE, ELF, DEX, APK, MachO, Raw };

struct SectionInfo {
    std::string name;
    std::string type_str;   // "CODE", "DATA", "BSS", …
    uint64_t    virt_addr  = 0;
    uint64_t    raw_offset = 0;
    uint64_t    raw_size   = 0;
    uint32_t    flags      = 0;
    double      entropy    = 0.0;
};

struct ImportEntry {
    std::string module;                 // DLL / shared-lib name
    std::vector<std::string> symbols;
};

struct ExportEntry {
    std::string name;
    uint64_t    address = 0;
    uint16_t    ordinal = 0;
};

struct ExtractedString {
    uint64_t    offset  = 0;
    std::string value;
    bool        unicode = false;
    int         score   = 0;   // "interestingness" — higher → show first
};

struct FileInfo {
    std::string filename;
    std::string filepath;
    std::string file_type_str;
    std::string architecture;
    std::string md5_hex;       // populated lazily
    uint64_t    file_size    = 0;
    uint64_t    entry_point  = 0;
    bool        is_64bit     = false;
    bool        is_packed    = false;   // entropy > 7.2 heuristic
    double      entropy      = 0.0;
};

// ─────────────────────────────────────────────────────────────────────────────
//  Helper: little-endian read from byte buffer
// ─────────────────────────────────────────────────────────────────────────────
template<typename T>
static T ReadLE(const uint8_t* buf, size_t offset, size_t buf_size) {
    if (offset + sizeof(T) > buf_size) return T{};
    T v; std::memcpy(&v, buf + offset, sizeof(T));
    return v;
}

// ─────────────────────────────────────────────────────────────────────────────
//  BinaryFile
// ─────────────────────────────────────────────────────────────────────────────
class BinaryFile {
public:
    // ── Public data ──────────────────────────────────────────────────────────
    std::vector<uint8_t>      raw;         // full file bytes
    FileInfo                  info;
    FileType                  type = FileType::Unknown;

    std::vector<SectionInfo>  sections;
    std::vector<ImportEntry>  imports;
    std::vector<ExportEntry>  exports;
    std::vector<ExtractedString> strings;
    std::vector<double>       entropy_map; // entropy per 256-byte block

    bool loaded  = false;
    std::string  load_error;

    // ── API ──────────────────────────────────────────────────────────────────
    bool Load(const std::string& path) {
        Clear();
        std::ifstream f(path, std::ios::binary | std::ios::ate);
        if (!f.is_open()) { load_error = "Cannot open file"; return false; }

        auto sz = static_cast<size_t>(f.tellg());
        f.seekg(0, std::ios::beg);
        raw.resize(sz);
        if (!f.read(reinterpret_cast<char*>(raw.data()), sz)) {
            load_error = "Read error"; return false;
        }

        info.filepath  = path;
        info.filename  = std::filesystem::path(path).filename().string();
        info.file_size = sz;

        DetectType();
        loaded = true;
        return true;
    }

    void Analyze() {
        if (!loaded) return;
        sections.clear(); imports.clear(); exports.clear();
        strings.clear();  entropy_map.clear();

        CalcEntropyMap();
        info.entropy   = BlockEntropy(raw.data(), raw.size());
        info.is_packed = (info.entropy > 7.2);
        ExtractStrings();
        ParseFormat();
    }

    // ── Utility ──────────────────────────────────────────────────────────────
    std::string FileSizeStr() const {
        if (info.file_size < 1024)       return std::to_string(info.file_size) + " B";
        if (info.file_size < 1024*1024)  return std::to_string(info.file_size/1024) + " KB";
        return std::to_string(info.file_size/(1024*1024)) + " MB";
    }

    // Hex dump of a region
    std::string HexDump(size_t offset, size_t len) const {
        std::ostringstream oss;
        size_t end = std::min(offset + len, raw.size());
        for (size_t i = offset; i < end; i += 16) {
            oss << std::hex << std::uppercase;
            oss.width(8); oss.fill('0'); oss << i << "  ";
            for (size_t j = i; j < std::min(i+16, end); j++) {
                oss.width(2); oss << (int)raw[j] << " ";
                if (j-i == 7) oss << " ";
            }
            size_t rem = (end-i < 16) ? 16-(end-i) : 0;
            for (size_t r = 0; r < rem; r++) oss << "   ";
            oss << " |";
            for (size_t j = i; j < std::min(i+16, end); j++)
                oss << (char)(raw[j] >= 0x20 && raw[j] <= 0x7E ? raw[j] : '.');
            oss << "|\n";
        }
        return oss.str();
    }

private:
    // ─── Detection ────────────────────────────────────────────────────────────
    void Clear() {
        raw.clear(); sections.clear(); imports.clear(); exports.clear();
        strings.clear(); entropy_map.clear();
        info = {}; type = FileType::Unknown;
        loaded = false; load_error.clear();
    }

    void DetectType() {
        const uint8_t* d = raw.data(); size_t n = raw.size();
        if (n < 4) { type = FileType::Raw; info.file_type_str = "Raw Binary"; return; }

        if (d[0]=='M' && d[1]=='Z')                              { type=FileType::PE;    info.file_type_str="Windows PE Executable"; }
        else if (d[0]==0x7F&&d[1]=='E'&&d[2]=='L'&&d[3]=='F')   { type=FileType::ELF;   info.file_type_str="ELF Binary (Linux/Android)"; }
        else if (n>=8&&d[0]=='d'&&d[1]=='e'&&d[2]=='x'&&d[3]=='\n') { type=FileType::DEX; info.file_type_str="Android Dalvik DEX"; }
        else if (d[0]=='P'&&d[1]=='K')                           { type=FileType::APK;   info.file_type_str="APK / ZIP Archive"; }
        else {
            uint32_t m = (d[0]<<24)|(d[1]<<16)|(d[2]<<8)|d[3];
            if (m==0xFEEDFACE||m==0xFEEDFACF||m==0xCEFAEDFE||m==0xCFFAEDFE)
                { type=FileType::MachO; info.file_type_str="Mach-O (macOS/iOS)"; }
            else { type=FileType::Raw; info.file_type_str="Raw/Unknown Binary"; }
        }
    }

    // ─── Entropy ──────────────────────────────────────────────────────────────
    static double BlockEntropy(const uint8_t* buf, size_t len) {
        if (!len) return 0.0;
        int freq[256] = {};
        for (size_t i = 0; i < len; i++) freq[buf[i]]++;
        double e = 0.0, total = static_cast<double>(len);
        for (auto f : freq) {
            if (f > 0) { double p = f/total; e -= p * std::log2(p); }
        }
        return e;
    }

    void CalcEntropyMap() {
        const size_t BLOCK = 256;
        for (size_t i = 0; i < raw.size(); i += BLOCK)
            entropy_map.push_back(BlockEntropy(raw.data()+i, std::min(BLOCK, raw.size()-i)));
    }

    // ─── String extraction ────────────────────────────────────────────────────
    void ExtractStrings() {
        const int MIN = 5;
        size_t i = 0;
        // ASCII pass
        while (i < raw.size()) {
            if (raw[i] >= 0x20 && raw[i] <= 0x7E) {
                size_t start = i;
                while (i < raw.size() && raw[i] >= 0x20 && raw[i] <= 0x7E) i++;
                if (i - start >= (size_t)MIN) {
                    ExtractedString s;
                    s.offset  = start;
                    s.unicode = false;
                    s.value   = std::string(raw.begin()+start, raw.begin()+i);
                    s.score   = Score(s.value);
                    strings.push_back(std::move(s));
                }
            } else i++;
        }
        // Sort by score descending
        std::sort(strings.begin(), strings.end(),
            [](const ExtractedString& a, const ExtractedString& b){ return a.score > b.score; });
    }

    int Score(const std::string& s) {
        int sc = static_cast<int>(std::min(s.size(), (size_t)50));
        auto lo = [](std::string x){ std::transform(x.begin(),x.end(),x.begin(),::tolower); return x; }(s);

        static const char* kw[] = {
            "password","passwd","token","secret","api_key","auth","bearer",
            "http://","https://","ftp://","socket","connect","remote",
            "admin","root","login","user","debug","flag","key","encrypt",
            "decrypt","base64","config","path","url","host",nullptr
        };
        for (int k=0; kw[k]; k++) if (lo.find(kw[k])!=std::string::npos) sc+=30;

        // URL heuristic
        if (lo.find("http")!=std::string::npos && lo.find("://")!=std::string::npos) sc+=25;
        // IP heuristic
        if (s.size()>=7&&s.size()<=15&&std::count(s.begin(),s.end(),'.')==3) sc+=20;

        return sc;
    }

    // ─── Format parsers ───────────────────────────────────────────────────────
    void ParseFormat() {
        switch(type) {
            case FileType::PE:  ParsePE();  break;
            case FileType::ELF: ParseELF(); break;
            case FileType::DEX: ParseDEX(); break;
            default: break;
        }
    }

    // ── PE ─────────────────────────────────────────────────────────────────
    void ParsePE() {
        const uint8_t* d = raw.data(); size_t n = raw.size();
        if (n < 0x40) return;

        uint32_t pe_off = ReadLE<uint32_t>(d, 0x3C, n);
        if (pe_off + 24 > n) return;
        if (ReadLE<uint32_t>(d, pe_off, n) != 0x00004550) return; // "PE\0\0"

        uint16_t machine       = ReadLE<uint16_t>(d, pe_off+4,  n);
        uint16_t num_secs      = ReadLE<uint16_t>(d, pe_off+6,  n);
        uint16_t opt_hdr_sz    = ReadLE<uint16_t>(d, pe_off+20, n);
        uint16_t magic         = ReadLE<uint16_t>(d, pe_off+24, n);

        info.is_64bit = (magic == 0x020B);

        switch(machine){
            case 0x8664: info.architecture="x86-64";               break;
            case 0x014C: info.architecture="x86 (32-bit)";         break;
            case 0xAA64: info.architecture="ARM64 (AArch64)";      break;
            case 0x01C4: info.architecture="ARM Thumb-2 (32-bit)"; break;
            case 0x01C0: info.architecture="ARM (32-bit)";         break;
            default:     info.architecture="Unknown ("+std::to_string(machine)+")"; break;
        }

        uint32_t ep_rva     = ReadLE<uint32_t>(d, pe_off+40, n);
        uint64_t image_base = info.is_64bit
            ? ReadLE<uint64_t>(d, pe_off+48, n)
            : ReadLE<uint32_t>(d, pe_off+52, n);
        info.entry_point = image_base + ep_rva;

        // ── Sections ──────────────────────────────────────────────────────
        size_t sec_base = pe_off + 24 + opt_hdr_sz;
        for (int i = 0; i < num_secs; i++) {
            size_t off = sec_base + i * 40;
            if (off + 40 > n) break;

            SectionInfo sec;
            char nm[9]={};
            std::memcpy(nm, d+off, 8);
            sec.name       = nm;
            sec.virt_addr  = ReadLE<uint32_t>(d, off+12, n) + image_base;
            sec.raw_size   = ReadLE<uint32_t>(d, off+16, n);
            sec.raw_offset = ReadLE<uint32_t>(d, off+20, n);
            sec.flags      = ReadLE<uint32_t>(d, off+36, n);

            if (sec.flags & 0x20000000) sec.type_str = "CODE";
            else if (sec.flags & 0x40000000) sec.type_str = "DATA (R/W)";
            else if (sec.flags & 0x80) sec.type_str = "BSS (Uninit)";
            else sec.type_str = "DATA";

            if (sec.raw_offset < n && sec.raw_size > 0)
                sec.entropy = BlockEntropy(d+sec.raw_offset,
                    std::min((size_t)sec.raw_size, n-sec.raw_offset));

            sections.push_back(sec);
        }

        // ── Import table (simplified RVA scan) ────────────────────────────
        // Import data directory: offset 120 (PE32) or 136 (PE32+) from start of opt header
        size_t import_dir_off = pe_off + 24 + (info.is_64bit ? 120 : 104);
        uint32_t import_rva = ReadLE<uint32_t>(d, import_dir_off, n);
        if (import_rva) {
            // Convert RVA → file offset via section map
            uint64_t import_foff = RVAtoOffset(import_rva, image_base);
            size_t ioff = (size_t)import_foff;
            while (ioff + 20 <= n) {
                uint32_t name_rva = ReadLE<uint32_t>(d, ioff+12, n);
                if (!name_rva) break;
                size_t name_foff = (size_t)RVAtoOffset(name_rva, image_base);
                if (name_foff >= n) break;

                ImportEntry ie;
                ie.module = reinterpret_cast<const char*>(d + name_foff);

                // Original first thunk → function names
                uint32_t ilt_rva = ReadLE<uint32_t>(d, ioff, n);
                if (!ilt_rva) ilt_rva = ReadLE<uint32_t>(d, ioff+16, n);
                size_t thunk_off = (size_t)RVAtoOffset(ilt_rva, image_base);
                for (int fn = 0; fn < 512 && thunk_off + 4 <= n; fn++) {
                    uint32_t thunk = ReadLE<uint32_t>(d, thunk_off, n);
                    if (!thunk) break;
                    if (!(thunk & 0x80000000)) {
                        size_t hint_off = (size_t)RVAtoOffset(thunk, image_base) + 2;
                        if (hint_off < n)
                            ie.symbols.push_back(reinterpret_cast<const char*>(d+hint_off));
                    }
                    thunk_off += 4;
                }
                imports.push_back(std::move(ie));
                ioff += 20;
            }
        }
    }

    uint64_t RVAtoOffset(uint32_t rva, uint64_t image_base) const {
        // Walk sections to convert RVA to file offset
        for (auto& sec : sections) {
            uint32_t sec_rva = static_cast<uint32_t>(sec.virt_addr - image_base);
            if (rva >= sec_rva && rva < sec_rva + sec.raw_size)
                return sec.raw_offset + (rva - sec_rva);
        }
        return rva; // fallback identity
    }

    // ── ELF ────────────────────────────────────────────────────────────────
    void ParseELF() {
        const uint8_t* d = raw.data(); size_t n = raw.size();
        if (n < 64) return;

        info.is_64bit = (d[4] == 2);
        uint16_t machine = ReadLE<uint16_t>(d, 18, n);

        switch(machine){
            case 3:   info.architecture="x86 (32-bit)";      break;
            case 62:  info.architecture="x86-64";             break;
            case 40:  info.architecture="ARM (32-bit)";       break;
            case 183: info.architecture="ARM64 (AArch64)";    break;
            case 8:   info.architecture="MIPS";               break;
            case 20:  info.architecture="PowerPC";            break;
            case 243: info.architecture="RISC-V";             break;
            default:  info.architecture="Unknown ("+std::to_string(machine)+")"; break;
        }

        if (info.is_64bit) {
            info.entry_point       = ReadLE<uint64_t>(d, 24, n);
            uint64_t shoff         = ReadLE<uint64_t>(d, 40, n);
            uint16_t shnum         = ReadLE<uint16_t>(d, 60, n);
            uint16_t shentsize     = ReadLE<uint16_t>(d, 58, n);
            uint16_t shstrndx      = ReadLE<uint16_t>(d, 62, n);

            // String table
            std::string strtab;
            if (shstrndx < shnum) {
                size_t so = (size_t)(shoff + shstrndx * shentsize);
                uint64_t data_off  = ReadLE<uint64_t>(d, so+24, n);
                uint64_t data_size = ReadLE<uint64_t>(d, so+32, n);
                if (data_off+data_size <= n)
                    strtab = std::string(d+data_off, d+data_off+data_size);
            }

            for (int i = 0; i < shnum; i++) {
                size_t so = (size_t)(shoff + i * shentsize);
                if (so + shentsize > n) break;

                uint32_t sh_name  = ReadLE<uint32_t>(d, so,    n);
                uint32_t sh_type  = ReadLE<uint32_t>(d, so+4,  n);
                uint64_t sh_flags = ReadLE<uint64_t>(d, so+8,  n);
                uint64_t sh_addr  = ReadLE<uint64_t>(d, so+16, n);
                uint64_t sh_off   = ReadLE<uint64_t>(d, so+24, n);
                uint64_t sh_size  = ReadLE<uint64_t>(d, so+32, n);

                if (sh_type == 0) continue; // SHT_NULL

                SectionInfo sec;
                sec.name       = (sh_name < strtab.size()) ? strtab.c_str()+sh_name : "";
                sec.virt_addr  = sh_addr;
                sec.raw_offset = sh_off;
                sec.raw_size   = sh_size;
                sec.flags      = static_cast<uint32_t>(sh_flags);

                if (sh_flags & 0x4)  sec.type_str = "CODE (Exec)";
                else if (sh_flags&0x1) sec.type_str = "DATA (Write)";
                else sec.type_str = "DATA (Read)";

                if (sh_off && sh_size && sh_off+sh_size <= n)
                    sec.entropy = BlockEntropy(d+(size_t)sh_off, (size_t)sh_size);

                sections.push_back(sec);
            }
        } else {
            // ELF32
            info.entry_point   = ReadLE<uint32_t>(d, 24, n);
            uint32_t shoff     = ReadLE<uint32_t>(d, 32, n);
            uint16_t shnum     = ReadLE<uint16_t>(d, 48, n);
            uint16_t shentsize = ReadLE<uint16_t>(d, 46, n);
            uint16_t shstrndx  = ReadLE<uint16_t>(d, 50, n);

            std::string strtab;
            if (shstrndx < shnum) {
                size_t so = shoff + shstrndx * shentsize;
                uint32_t data_off  = ReadLE<uint32_t>(d, so+16, n);
                uint32_t data_size = ReadLE<uint32_t>(d, so+20, n);
                if (data_off+data_size <= n)
                    strtab = std::string(d+data_off, d+data_off+data_size);
            }

            for (int i = 0; i < shnum; i++) {
                size_t so = shoff + i * shentsize;
                if (so + shentsize > n) break;

                uint32_t sh_name  = ReadLE<uint32_t>(d, so,    n);
                uint32_t sh_type  = ReadLE<uint32_t>(d, so+4,  n);
                uint32_t sh_flags = ReadLE<uint32_t>(d, so+8,  n);
                uint32_t sh_addr  = ReadLE<uint32_t>(d, so+12, n);
                uint32_t sh_off   = ReadLE<uint32_t>(d, so+16, n);
                uint32_t sh_size  = ReadLE<uint32_t>(d, so+20, n);

                if (sh_type == 0) continue;

                SectionInfo sec;
                sec.name       = (sh_name < strtab.size()) ? strtab.c_str()+sh_name : "";
                sec.virt_addr  = sh_addr;
                sec.raw_offset = sh_off;
                sec.raw_size   = sh_size;
                sec.flags      = sh_flags;
                sec.type_str   = (sh_flags&0x4) ? "CODE" : ((sh_flags&0x1) ? "DATA (W)" : "DATA");
                if (sh_off && sh_size && sh_off+sh_size <= n)
                    sec.entropy = BlockEntropy(d+sh_off, sh_size);
                sections.push_back(sec);
            }
        }
    }

    // ── DEX ────────────────────────────────────────────────────────────────
    void ParseDEX() {
        const uint8_t* d = raw.data(); size_t n = raw.size();
        if (n < 112) return;

        info.is_64bit     = false;
        info.architecture = "Dalvik VM";

        char ver[4] = {};
        std::memcpy(ver, d+4, 3);
        info.file_type_str = std::string("Android DEX (ver ") + ver + ")";

        uint32_t str_ids_sz  = ReadLE<uint32_t>(d, 56, n);
        uint32_t str_ids_off = ReadLE<uint32_t>(d, 60, n);
        uint32_t type_ids_sz = ReadLE<uint32_t>(d, 64, n);
        uint32_t type_ids_off= ReadLE<uint32_t>(d, 68, n);
        uint32_t cls_defs_sz = ReadLE<uint32_t>(d, 96, n);
        uint32_t cls_defs_off= ReadLE<uint32_t>(d, 100, n);
        uint32_t data_sz     = ReadLE<uint32_t>(d, 104, n);
        uint32_t data_off    = ReadLE<uint32_t>(d, 108, n);

        auto add = [&](const char* nm, const char* t, uint32_t off, uint32_t sz){
            SectionInfo s; s.name=nm; s.type_str=t;
            s.raw_offset=off; s.raw_size=sz; s.virt_addr=off;
            if (off&&sz&&off+sz<=n) s.entropy=BlockEntropy(d+off,sz);
            sections.push_back(s);
        };

        add("header",    "DEX Header",    0,            112);
        add("string_ids","String IDs",    str_ids_off,  str_ids_sz*4);
        add("type_ids",  "Type IDs",      type_ids_off, type_ids_sz*4);
        add("class_defs","Class Defs",    cls_defs_off, cls_defs_sz*32);
        add("data",      "Data Section",  data_off,     data_sz);
    }
};

} // namespace RS
