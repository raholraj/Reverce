#pragma once
// ╔══════════════════════════════════════════════════════════════════════════╗
// ║             ReverseShield — ImGui Application (SDL2 + OpenGL3)         ║
// ╚══════════════════════════════════════════════════════════════════════════╝

#include "imgui.h"
#include "imgui_impl_sdl2.h"
#include "imgui_impl_opengl3.h"
#include "implot.h"

#include <SDL.h>
#include <SDL_opengl.h>

#include "../core/binary_file.hpp"

#include <algorithm>
#include <array>
#include <cstdio>
#include <string>
#include <vector>

namespace RS {

// ─────────────────────────────────────────────────────────────────────────────
//  Theme
// ─────────────────────────────────────────────────────────────────────────────
static void ApplyTheme() {
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding    = 6.f;
    s.FrameRounding     = 4.f;
    s.ScrollbarRounding = 4.f;
    s.GrabRounding      = 4.f;
    s.TabRounding       = 4.f;
    s.WindowBorderSize  = 1.f;
    s.FrameBorderSize   = 0.f;
    s.PopupRounding     = 4.f;
    s.ItemSpacing       = {6,4};
    s.FramePadding      = {8,4};

    // Neon-on-dark palette
    auto C = [](int r,int g,int b,int a=255){ return ImVec4(r/255.f,g/255.f,b/255.f,a/255.f); };

    ImVec4* col = s.Colors;
    col[ImGuiCol_WindowBg]         = C( 13, 13, 20);
    col[ImGuiCol_ChildBg]          = C( 18, 18, 28);
    col[ImGuiCol_PopupBg]          = C( 20, 20, 32);
    col[ImGuiCol_Border]           = C( 50, 50, 75);
    col[ImGuiCol_FrameBg]          = C( 25, 25, 38);
    col[ImGuiCol_FrameBgHovered]   = C( 35, 35, 55);
    col[ImGuiCol_FrameBgActive]    = C( 40, 40, 65);
    col[ImGuiCol_TitleBg]          = C( 15, 15, 25);
    col[ImGuiCol_TitleBgActive]    = C( 20, 20, 38);
    col[ImGuiCol_MenuBarBg]        = C( 15, 15, 25);
    col[ImGuiCol_ScrollbarBg]      = C( 13, 13, 20);
    col[ImGuiCol_ScrollbarGrab]    = C( 60, 60, 100);
    col[ImGuiCol_ScrollbarGrabH]   = C( 80, 80, 130);
    col[ImGuiCol_ScrollbarGrabA]   = C(100,100,160);
    col[ImGuiCol_CheckMark]        = C( 80,220,120);
    col[ImGuiCol_SliderGrab]       = C( 80,220,120);
    col[ImGuiCol_SliderGrabActive] = C(120,255,160);
    col[ImGuiCol_Button]           = C( 30, 90, 60);
    col[ImGuiCol_ButtonHovered]    = C( 50,140, 90);
    col[ImGuiCol_ButtonActive]     = C( 70,180,120);
    col[ImGuiCol_Header]           = C( 30, 80, 60,180);
    col[ImGuiCol_HeaderHovered]    = C( 50,120, 90);
    col[ImGuiCol_HeaderActive]     = C( 70,160,120);
    col[ImGuiCol_Tab]              = C( 20, 20, 35);
    col[ImGuiCol_TabHovered]       = C( 50,150,100);
    col[ImGuiCol_TabActive]        = C( 40,130, 85);
    col[ImGuiCol_TabUnfocused]     = C( 18, 18, 30);
    col[ImGuiCol_TabUnfocusedActive]= C(30, 80, 60);
    col[ImGuiCol_DockingPreview]   = C( 80,220,120, 80);
    col[ImGuiCol_DockingEmptyBg]   = C(  8,  8, 15);
    col[ImGuiCol_Separator]        = C( 50, 50, 75);
    col[ImGuiCol_ResizeGrip]       = C( 50,180,100, 60);
    col[ImGuiCol_ResizeGripHovered]= C( 80,220,130,100);
    col[ImGuiCol_ResizeGripActive] = C(120,255,160,180);
    col[ImGuiCol_Text]             = C(220,225,230);
    col[ImGuiCol_TextDisabled]     = C( 90, 95,105);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Colour helpers
// ─────────────────────────────────────────────────────────────────────────────
static ImVec4 EntropyColor(double e) {
    if (e < 3.0) return {0.30f,0.85f,0.45f,1.f};  // green  – structured
    if (e < 5.5) return {0.90f,0.80f,0.20f,1.f};  // yellow – mixed
    if (e < 7.0) return {0.95f,0.50f,0.10f,1.f};  // orange – compressed?
    return            {0.95f,0.20f,0.20f,1.f};     // red    – encrypted/packed
}

// ─────────────────────────────────────────────────────────────────────────────
//  Hex Panel
// ─────────────────────────────────────────────────────────────────────────────
class HexPanel {
    static constexpr int COLS = 16;
    int      sel_byte     = -1;
    int      sel_col      = -1;    // 0=hex, 1=ascii
    char     search_buf[128] = {};
    bool     search_hex   = false;
    std::vector<size_t> search_hits;
    size_t   search_cur   = 0;

public:
    void Reset() { sel_byte=-1; search_hits.clear(); std::memset(search_buf,0,sizeof(search_buf)); }

    void Render(const BinaryFile& bf) {
        ImGui::Begin("  Hex View");
        if (bf.raw.empty()) { ImGui::TextDisabled("(no file loaded)"); ImGui::End(); return; }

        const auto& data = bf.raw;

        // ── Toolbar ──────────────────────────────────────────────────────────
        ImGui::SetNextItemWidth(220);
        ImGui::InputText("##search", search_buf, sizeof(search_buf));
        ImGui::SameLine();
        ImGui::Checkbox("Hex", &search_hex);
        ImGui::SameLine();
        if (ImGui::Button("Find##hex")) DoSearch(data);
        ImGui::SameLine();
        if (!search_hits.empty()) {
            ImGui::TextColored({0.5f,1.f,0.6f,1.f}, "%zu hits", search_hits.size());
            ImGui::SameLine();
            if (ImGui::ArrowButton("##prev",ImGuiDir_Left)  && search_cur > 0) search_cur--;
            ImGui::SameLine();
            if (ImGui::ArrowButton("##next",ImGuiDir_Right) && search_cur+1 < search_hits.size()) search_cur++;
        }
        ImGui::Separator();

        // ── Hex grid ─────────────────────────────────────────────────────────
        float line_h = ImGui::GetTextLineHeight() + 2.f;
        size_t total_rows = (data.size() + COLS - 1) / COLS;

        // Column headers
        ImGui::TextColored({0.4f,0.7f,1.f,1.f}, "Offset    ");
        for (int c=0;c<COLS;c++) {
            ImGui::SameLine(); ImGui::TextColored({0.4f,0.7f,1.f,1.f}," %02X", c);
            if (c==7) ImGui::SameLine(0,8);
        }
        ImGui::SameLine(); ImGui::TextColored({0.4f,0.7f,1.f,1.f},"  ASCII");
        ImGui::Separator();

        // Clipper for large files
        ImGuiListClipper clipper;
        clipper.Begin((int)total_rows);
        while (clipper.Step()) {
            for (int row = clipper.DisplayStart; row < clipper.DisplayEnd; row++) {
                size_t base = row * COLS;
                size_t end  = std::min(base + COLS, data.size());

                // Offset
                ImGui::TextColored({0.5f,0.5f,0.7f,1.f}, "%08zX  ", base);

                // Hex bytes
                for (size_t i = base; i < end; i++) {
                    ImGui::SameLine();
                    if (i == base+8) ImGui::SameLine(0,8);

                    bool hit = IsHit(i);
                    bool sel = (sel_byte == (int)i);
                    uint8_t b = data[i];

                    ImVec4 col;
                    if      (sel) col = {1.f, 1.f, 0.2f, 1.f};
                    else if (hit) col = {0.2f,1.f, 0.4f, 1.f};
                    else if (b==0) col = {0.3f,0.3f,0.4f,1.f};
                    else if (b<0x20||b==0xFF) col = {0.9f,0.4f,0.4f,1.f};
                    else col = {0.85f,0.9f,0.95f,1.f};

                    ImGui::TextColored(col, " %02X", b);
                    if (ImGui::IsItemClicked()) { sel_byte=(int)i; sel_col=0; }
                    if (ImGui::IsItemHovered()) {
                        ImGui::BeginTooltip();
                        ImGui::Text("Offset: 0x%zX  Dec: %u  Char: %c",
                            i, b, (b>=0x20&&b<=0x7E)?b:'.');
                        ImGui::EndTooltip();
                    }
                }

                // Padding for partial rows
                for (size_t i=end; i<base+COLS; i++) {
                    ImGui::SameLine(); if(i==base+8) ImGui::SameLine(0,8);
                    ImGui::TextDisabled("   ");
                }

                // ASCII
                ImGui::SameLine(); ImGui::TextDisabled("  ");
                for (size_t i = base; i < end; i++) {
                    ImGui::SameLine(0,0);
                    uint8_t b = data[i];
                    char c = (b>=0x20&&b<=0x7E) ? (char)b : '.';
                    bool sel2 = (sel_byte==(int)i);
                    ImVec4 col2 = sel2 ? ImVec4{1,1,0.2f,1} : IsHit(i) ? ImVec4{0.2f,1,0.4f,1}
                                       : (b==0) ? ImVec4{0.3f,0.3f,0.4f,1}
                                       : (b<0x20||b>0x7E) ? ImVec4{0.9f,0.4f,0.4f,1}
                                       : ImVec4{0.7f,0.95f,0.8f,1};
                    char tmp[2] = {c,0};
                    ImGui::TextColored(col2, "%s", tmp);
                    if (ImGui::IsItemClicked()) { sel_byte=(int)i; sel_col=1; }
                }
            }
        }

        // ── Bottom status ─────────────────────────────────────────────────────
        ImGui::Separator();
        if (sel_byte >= 0 && sel_byte < (int)data.size()) {
            uint8_t b = data[sel_byte];
            ImGui::TextColored({0.5f,1.f,0.7f,1.f},
                "Byte @ 0x%X = 0x%02X  Dec:%u  Char:'%c'  Entropy-block:%.2f",
                sel_byte, b, b, (b>=0x20&&b<0x7E)?b:'.',
                bf.entropy_map.empty() ? 0.0
                    : bf.entropy_map[std::min((size_t)sel_byte/256, bf.entropy_map.size()-1)]);
        } else {
            ImGui::TextDisabled("Click a byte to inspect");
        }
        ImGui::End();
    }

private:
    bool IsHit(size_t i) {
        if (!search_hits.empty() && search_cur < search_hits.size())
            return i >= search_hits[search_cur] && i < search_hits[search_cur]+strlen(search_buf);
        return false;
    }

    void DoSearch(const std::vector<uint8_t>& data) {
        search_hits.clear(); search_cur=0;
        if (!search_buf[0]) return;
        if (search_hex) {
            // Parse hex pairs
            std::vector<uint8_t> pattern;
            const char* p = search_buf;
            while (*p) {
                while (*p==' ') p++;
                if (!*p) break;
                char hi=*p++, lo=*p++;
                auto hex=[](char c)->int{ return c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:c>='A'&&c<='F'?c-'A'+10:-1; };
                int h=hex(hi), l=hex(lo);
                if (h<0||l<0) break;
                pattern.push_back((uint8_t)(h<<4|l));
            }
            if (!pattern.empty()) {
                auto it = data.begin();
                while ((it=std::search(it,data.end(),pattern.begin(),pattern.end()))!=data.end()) {
                    search_hits.push_back(it-data.begin()); ++it;
                }
            }
        } else {
            std::string pat(search_buf);
            size_t pos=0;
            while ((pos=std::string(data.begin()+pos,data.end()).find(pat))!=std::string::npos) {
                search_hits.push_back(pos); pos++;
                if (pos >= data.size()) break;
            }
        }
    }
};

// ─────────────────────────────────────────────────────────────────────────────
//  Entropy Panel
// ─────────────────────────────────────────────────────────────────────────────
class EntropyPanel {
public:
    void Render(const BinaryFile& bf) {
        ImGui::Begin("  Entropy");
        if (bf.entropy_map.empty()) { ImGui::TextDisabled("(analyze a file first)"); ImGui::End(); return; }

        double overall = bf.info.entropy;
        ImVec4 ec = EntropyColor(overall);
        ImGui::Text("Overall entropy: ");
        ImGui::SameLine();
        ImGui::TextColored(ec, "%.4f / 8.0", overall);
        ImGui::SameLine();
        if (overall > 7.2)
            ImGui::TextColored({0.95f,0.2f,0.2f,1.f}, " [PACKED / ENCRYPTED?]");
        else if (overall > 5.5)
            ImGui::TextColored({0.95f,0.6f,0.1f,1.f}, " [Compressed?]");
        else
            ImGui::TextColored({0.3f,0.85f,0.45f,1.f}, " [Structured]");

        // Entropy progress bar
        ImGui::ProgressBar((float)(overall/8.0), ImVec2(-1,8), "");

        ImGui::Separator();
        ImGui::TextDisabled("Per-256-byte block entropy (red = high = possible encryption)");

        if (ImPlot::BeginPlot("##entropy", ImVec2(-1, 180))) {
            ImPlot::SetupAxes("Block","Shannon Entropy");
            ImPlot::SetupAxisLimits(ImAxis_Y1, 0.0, 8.5, ImGuiCond_Always);

            // Build xs/ys
            int N = (int)bf.entropy_map.size();
            std::vector<float> xs(N), ys(N);
            for (int i=0;i<N;i++) { xs[i]=(float)i; ys[i]=(float)bf.entropy_map[i]; }

            // Threshold line
            static float thresh[2]={0.f,0.f};
            thresh[0]=0.f; thresh[1]=(float)(N-1);
            float t7[2]={7.2f,7.2f};
            ImPlot::SetNextLineStyle({0.95f,0.2f,0.2f,0.6f},1.f);
            ImPlot::PlotLine("##t72", thresh, t7, 2);

            ImPlot::SetNextFillStyle({0.2f,0.8f,0.4f,0.3f});
            ImPlot::SetNextLineStyle({0.3f,1.f,0.5f,1.f},1.5f);
            ImPlot::PlotLine("Entropy", xs.data(), ys.data(), N);
            ImPlot::PlotShaded("##shade", xs.data(), ys.data(), N, 0.0);
            ImPlot::EndPlot();
        }

        // Section entropy table
        if (!bf.sections.empty()) {
            ImGui::Separator();
            ImGui::TextColored({0.4f,0.7f,1.f,1.f}, "Section Entropy");
            if (ImGui::BeginTable("##sec_entropy", 3, ImGuiTableFlags_Borders|ImGuiTableFlags_RowBg|ImGuiTableFlags_Resizable)) {
                ImGui::TableSetupColumn("Section"); ImGui::TableSetupColumn("Type"); ImGui::TableSetupColumn("Entropy");
                ImGui::TableHeadersRow();
                for (auto& sec : bf.sections) {
                    ImGui::TableNextRow();
                    ImGui::TableNextColumn(); ImGui::Text("%s", sec.name.c_str());
                    ImGui::TableNextColumn(); ImGui::TextDisabled("%s", sec.type_str.c_str());
                    ImGui::TableNextColumn();
                    ImGui::TextColored(EntropyColor(sec.entropy), "%.4f", sec.entropy);
                }
                ImGui::EndTable();
            }
        }
        ImGui::End();
    }
};

// ─────────────────────────────────────────────────────────────────────────────
//  Strings Panel
// ─────────────────────────────────────────────────────────────────────────────
class StringsPanel {
    char  filter_buf[128] = {};
    bool  show_offset = true;
    int   min_score   = 0;
    bool  highlight_interesting = true;

public:
    void Render(const BinaryFile& bf, int* jump_offset) {
        ImGui::Begin("  Strings");
        if (bf.strings.empty()) { ImGui::TextDisabled("(no strings extracted yet)"); ImGui::End(); return; }

        // Filter bar
        ImGui::SetNextItemWidth(200);
        ImGui::InputText("Filter##str", filter_buf, sizeof(filter_buf));
        ImGui::SameLine();
        ImGui::Checkbox("Offsets", &show_offset);
        ImGui::SameLine();
        ImGui::Checkbox("Highlight", &highlight_interesting);
        ImGui::SameLine();
        ImGui::SetNextItemWidth(80);
        ImGui::SliderInt("Min Score", &min_score, 0, 100);
        ImGui::Separator();

        std::string filter(filter_buf);
        size_t shown = 0;

        if (ImGui::BeginTable("##strtab", show_offset ? 3 : 2,
            ImGuiTableFlags_Borders|ImGuiTableFlags_RowBg|ImGuiTableFlags_ScrollY|
            ImGuiTableFlags_Resizable, ImVec2(0,-1))) {

            if (show_offset) ImGui::TableSetupColumn("Offset", ImGuiTableColumnFlags_WidthFixed, 90);
            ImGui::TableSetupColumn("Score",  ImGuiTableColumnFlags_WidthFixed, 55);
            ImGui::TableSetupColumn("String", ImGuiTableColumnFlags_WidthStretch);
            ImGui::TableSetupScrollFreeze(0,1);
            ImGui::TableHeadersRow();

            for (auto& s : bf.strings) {
                if (s.score < min_score) continue;
                if (!filter.empty() && s.value.find(filter) == std::string::npos) continue;

                ImGui::TableNextRow();

                bool interesting = s.score >= 40;
                ImVec4 tc = interesting && highlight_interesting
                    ? ImVec4{1.f,0.85f,0.2f,1.f} : ImVec4{0.85f,0.9f,0.95f,1.f};

                if (show_offset) {
                    ImGui::TableNextColumn();
                    if (ImGui::Selectable(("##s"+std::to_string(s.offset)).c_str(), false,
                            ImGuiSelectableFlags_SpanAllColumns)) {
                        if (jump_offset) *jump_offset = (int)s.offset;
                    }
                    ImGui::SameLine();
                    ImGui::TextColored({0.5f,0.5f,0.7f,1.f}, "0x%08zX", s.offset);
                }
                ImGui::TableNextColumn();
                ImGui::TextColored(interesting&&highlight_interesting
                    ? ImVec4{0.3f,1.f,0.5f,1.f} : ImVec4{0.5f,0.5f,0.6f,1.f},
                    "%d", s.score);
                ImGui::TableNextColumn();
                ImGui::TextColored(tc, "%s", s.value.c_str());
                shown++;
            }
            ImGui::EndTable();
        }
        ImGui::TextDisabled("Showing %zu / %zu strings", shown, bf.strings.size());
        ImGui::End();
    }
};

// ─────────────────────────────────────────────────────────────────────────────
//  Info + Sections Panel
// ─────────────────────────────────────────────────────────────────────────────
class InfoPanel {
public:
    void Render(const BinaryFile& bf) {
        ImGui::Begin("  File Info");

        if (!bf.loaded) {
            ImGui::Spacing();
            ImGui::TextColored({0.4f,0.7f,1.f,1.f}, "ReverseShield");
            ImGui::TextDisabled("Drag & drop a binary or use File → Open");
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextDisabled("Supports: PE, ELF, DEX, APK/ZIP, Mach-O");
            ImGui::End();
            return;
        }

        const auto& fi = bf.info;
        auto Row = [](const char* label, const char* val, ImVec4 c={0.85f,0.9f,0.95f,1.f}) {
            ImGui::TextDisabled("%s", label);
            ImGui::SameLine(110);
            ImGui::TextColored(c, "%s", val);
        };

        ImGui::TextColored({0.4f,1.f,0.65f,1.f}, "%s", fi.filename.c_str());
        ImGui::Separator();

        Row("Type:",   fi.file_type_str.c_str());
        Row("Arch:",   fi.architecture.empty() ? "—" : fi.architecture.c_str());
        Row("Bits:",   fi.is_64bit ? "64-bit" : "32-bit");
        Row("Size:",   bf.FileSizeStr().c_str());

        char ep_buf[32]; std::snprintf(ep_buf,32,"0x%llX",(unsigned long long)fi.entry_point);
        Row("Entry:",  fi.entry_point ? ep_buf : "—");

        char ent_buf[32]; std::snprintf(ent_buf,32,"%.4f / 8.00", fi.entropy);
        Row("Entropy:",ent_buf, EntropyColor(fi.entropy));

        if (fi.is_packed) {
            ImGui::Spacing();
            ImGui::TextColored({0.95f,0.2f,0.2f,1.f}, "  POSSIBLE PACKING / ENCRYPTION");
        }

        ImGui::Spacing();
        ImGui::Separator();

        // ── Sections ──────────────────────────────────────────────────────────
        if (!bf.sections.empty()) {
            ImGui::TextColored({0.4f,0.7f,1.f,1.f}, "Sections / Segments (%zu)", bf.sections.size());
            if (ImGui::BeginTable("##secs", 5,
                ImGuiTableFlags_Borders|ImGuiTableFlags_RowBg|ImGuiTableFlags_ScrollY|
                ImGuiTableFlags_Resizable, ImVec2(0,200))) {

                ImGui::TableSetupColumn("Name",    ImGuiTableColumnFlags_WidthFixed,   80);
                ImGui::TableSetupColumn("Type",    ImGuiTableColumnFlags_WidthFixed,   80);
                ImGui::TableSetupColumn("Offset",  ImGuiTableColumnFlags_WidthFixed,   75);
                ImGui::TableSetupColumn("Size",    ImGuiTableColumnFlags_WidthFixed,   70);
                ImGui::TableSetupColumn("Entropy", ImGuiTableColumnFlags_WidthFixed,   60);
                ImGui::TableSetupScrollFreeze(0,1);
                ImGui::TableHeadersRow();

                for (auto& sec : bf.sections) {
                    ImGui::TableNextRow();
                    ImGui::TableNextColumn(); ImGui::Text("%s", sec.name.c_str());
                    ImGui::TableNextColumn(); ImGui::TextDisabled("%s",sec.type_str.c_str());
                    ImGui::TableNextColumn(); ImGui::Text("0x%llX",(unsigned long long)sec.raw_offset);
                    ImGui::TableNextColumn(); ImGui::Text("0x%llX",(unsigned long long)sec.raw_size);
                    ImGui::TableNextColumn(); ImGui::TextColored(EntropyColor(sec.entropy),"%.2f",sec.entropy);
                }
                ImGui::EndTable();
            }
        }

        // ── Imports ───────────────────────────────────────────────────────────
        if (!bf.imports.empty()) {
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored({0.4f,0.7f,1.f,1.f}, "Imports (%zu modules)", bf.imports.size());
            ImGui::PushStyleVar(ImGuiStyleVar_IndentSpacing, 12.f);
            for (auto& imp : bf.imports) {
                if (ImGui::TreeNode(imp.module.c_str())) {
                    for (auto& fn : imp.symbols)
                        ImGui::TextColored({0.7f,0.9f,0.7f,1.f}, "  %s", fn.c_str());
                    ImGui::TreePop();
                }
            }
            ImGui::PopStyleVar();
        }

        ImGui::End();
    }
};

// ─────────────────────────────────────────────────────────────────────────────
//  Main App
// ─────────────────────────────────────────────────────────────────────────────
class App {
    SDL_Window*   window  = nullptr;
    SDL_GLContext gl_ctx  = nullptr;
    bool          running = true;

    BinaryFile    bf;
    HexPanel      hex_panel;
    EntropyPanel  entropy_panel;
    StringsPanel  strings_panel;
    InfoPanel     info_panel;

    bool  show_demo      = false;
    bool  show_about     = false;
    char  open_path[512] = {};
    int   jump_offset    = -1;
    std::string status_msg;

    // Drag-drop overlay
    bool  dd_hover = false;

public:
    bool Initialize() {
        if (SDL_Init(SDL_INIT_VIDEO|SDL_INIT_TIMER) != 0) {
            SDL_Log("SDL_Init: %s", SDL_GetError()); return false;
        }

        SDL_GL_SetAttribute(SDL_GL_CONTEXT_FLAGS,         SDL_GL_CONTEXT_FORWARD_COMPATIBLE_FLAG);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK,  SDL_GL_CONTEXT_PROFILE_CORE);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
        SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
        SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE,  24);
        SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 8);

        window = SDL_CreateWindow(
            "ReverseShield  —  Binary Analysis Tool",
            SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
            1400, 860,
            SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI
        );
        if (!window) return false;

        gl_ctx = SDL_GL_CreateContext(window);
        SDL_GL_MakeCurrent(window, gl_ctx);
        SDL_GL_SetSwapInterval(1);

        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImPlot::CreateContext();

        ImGuiIO& io = ImGui::GetIO();
        io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
        io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;

        ApplyTheme();

        ImGui_ImplSDL2_InitForOpenGL(window, gl_ctx);
        ImGui_ImplOpenGL3_Init("#version 330");

        status_msg = "Ready — open or drag-drop a binary file";
        return true;
    }

    void Run() {
        while (running) {
            PollEvents();
            NewFrame();
            RenderUI();
            Present();
        }
    }

    void Shutdown() {
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplSDL2_Shutdown();
        ImPlot::DestroyContext();
        ImGui::DestroyContext();
        SDL_GL_DeleteContext(gl_ctx);
        SDL_DestroyWindow(window);
        SDL_Quit();
    }

private:
    void PollEvents() {
        SDL_Event e;
        dd_hover = false;
        while (SDL_PollEvent(&e)) {
            ImGui_ImplSDL2_ProcessEvent(&e);
            if (e.type == SDL_QUIT)
                running = false;
            if (e.type == SDL_WINDOWEVENT && e.window.event == SDL_WINDOWEVENT_CLOSE
                    && e.window.windowID == SDL_GetWindowID(window))
                running = false;

            // Drag-and-drop
            if (e.type == SDL_DROPFILE) {
                LoadFile(e.drop.file);
                SDL_free(e.drop.file);
            }
        }
    }

    void NewFrame() {
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplSDL2_NewFrame();
        ImGui::NewFrame();
    }

    void Present() {
        ImGui::Render();
        int w,h; SDL_GL_GetDrawableSize(window, &w, &h);
        glViewport(0,0,w,h);
        glClearColor(0.05f,0.05f,0.08f,1.f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        SDL_GL_SwapWindow(window);
    }

    void LoadFile(const char* path) {
        hex_panel.Reset();
        status_msg = std::string("Loading: ") + path + " …";
        bf = BinaryFile{};
        if (!bf.Load(path)) {
            status_msg = std::string("Error: ") + bf.load_error;
            return;
        }
        status_msg = "Analyzing …";
        bf.Analyze();
        status_msg = "Loaded: " + bf.info.filename
            + "  (" + bf.FileSizeStr() + ")"
            + "  Type: " + bf.info.file_type_str
            + "  Entropy: " + [&]{ char b[16]; std::snprintf(b,16,"%.3f",bf.info.entropy); return std::string(b); }();
    }

    void RenderUI() {
        // ── Fullscreen dockspace ──────────────────────────────────────────────
        ImGuiViewport* vp = ImGui::GetMainViewport();
        ImGui::SetNextWindowPos(vp->WorkPos);
        ImGui::SetNextWindowSize(vp->WorkSize);
        ImGui::SetNextWindowViewport(vp->ID);

        ImGuiWindowFlags host_flags =
            ImGuiWindowFlags_NoDocking | ImGuiWindowFlags_NoTitleBar |
            ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoBringToFrontOnFocus |
            ImGuiWindowFlags_NoNavFocus | ImGuiWindowFlags_MenuBar;

        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {0,0});
        ImGui::Begin("##dock_host", nullptr, host_flags);
        ImGui::PopStyleVar(3);

        // ── Menu bar ─────────────────────────────────────────────────────────
        if (ImGui::BeginMenuBar()) {
            ImGui::TextColored({0.3f,1.f,0.5f,1.f}, "  ReverseShield ");

            if (ImGui::BeginMenu("File")) {
                if (ImGui::MenuItem("Open…", "Ctrl+O"))       ImGui::OpenPopup("##open_dialog");
                if (ImGui::MenuItem("Close",  nullptr, false, bf.loaded)) bf=BinaryFile{}; hex_panel.Reset();
                ImGui::Separator();
                if (ImGui::MenuItem("Quit",  "Alt+F4"))       running=false;
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("View")) {
                if (ImGui::MenuItem("ImGui Demo",  nullptr, show_demo))  show_demo  = !show_demo;
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Analyze")) {
                if (ImGui::MenuItem("Re-analyze", nullptr, false, bf.loaded)) bf.Analyze();
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Help")) {
                if (ImGui::MenuItem("About")) show_about = true;
                ImGui::EndMenu();
            }

            // Status in menu bar
            ImGui::SetCursorPosX(ImGui::GetContentRegionMax().x - 500);
            ImGui::TextDisabled("%s", status_msg.c_str());
            ImGui::EndMenuBar();
        }

        // ── Open file dialog popup ────────────────────────────────────────────
        if (ImGui::BeginPopupModal("##open_dialog", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
            ImGui::Text("File path:");
            ImGui::SetNextItemWidth(400);
            ImGui::InputText("##op", open_path, sizeof(open_path));
            ImGui::SameLine();
            if (ImGui::Button("Load")) { LoadFile(open_path); ImGui::CloseCurrentPopup(); }
            ImGui::SameLine();
            if (ImGui::Button("Cancel")) ImGui::CloseCurrentPopup();
            ImGui::EndPopup();
        }

        // ── Dockspace ────────────────────────────────────────────────────────
        ImGuiID dsid = ImGui::GetID("MainDockSpace");
        ImGui::DockSpace(dsid, {0,0}, ImGuiDockNodeFlags_PassthruCentralNode);
        ImGui::End();

        // ── Panels ───────────────────────────────────────────────────────────
        info_panel.Render(bf);
        hex_panel.Render(bf);
        entropy_panel.Render(bf);
        strings_panel.Render(bf, &jump_offset);

        // ── About ─────────────────────────────────────────────────────────────
        if (show_about) {
            ImGui::Begin("About ReverseShield", &show_about, ImGuiWindowFlags_AlwaysAutoResize);
            ImGui::TextColored({0.3f,1.f,0.5f,1.f}, "ReverseShield v1.0");
            ImGui::TextDisabled("A lightweight C++20 binary analysis toolkit");
            ImGui::Separator();
            ImGui::BulletText("PE, ELF, DEX, APK, Mach-O parsing");
            ImGui::BulletText("Hex editor with search");
            ImGui::BulletText("Shannon entropy visualisation");
            ImGui::BulletText("Scored string extraction");
            ImGui::BulletText("Import / Export table viewer");
            ImGui::Separator();
            ImGui::TextDisabled("Built with Dear ImGui + ImPlot + SDL2");
            if (ImGui::Button("Close")) show_about=false;
            ImGui::End();
        }

        if (show_demo) ImGui::ShowDemoWindow(&show_demo);
    }
};

} // namespace RS
