// ╔══════════════════════════════════════════════════════════════╗
// ║          ReverseShield — Entry Point                        ║
// ╚══════════════════════════════════════════════════════════════╝
#include "ui/app.hpp"

int main(int argc, char** argv) {
    RS::App app;

    if (!app.Initialize()) {
        SDL_Log("Failed to initialize ReverseShield");
        return 1;
    }

    // Optional: load file from CLI argument
    // (argc > 1 → pass argv[1] to app via a public Load() shim if desired)

    app.Run();
    app.Shutdown();
    return 0;
}
